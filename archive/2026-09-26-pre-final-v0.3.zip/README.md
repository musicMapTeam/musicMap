# Music Map

从喜欢出发，把音乐旅程留下。沿真实艺人关系发现音乐，将主动留下的歌曲与路线收进 Music Space 私人档案。

赛道：**创新音乐产品**。初赛截止：**2026-10-09 23:59**。

## 当前情况

- **文档 v0.3 已整理**：Map × Space 整合、视觉方向、Hugging Face 数据研究、技术选型、排期与参赛材料。
- **现有原型仍为 v0.2**：虚构艺人、歌曲与关系，试听是明确标识的无声模拟。新版真实音频、封套、Space 和部署尚未实现。
- 已核验一个 MusicBrainz 合作样例；官方提供赛事限定用途音乐歌单。完整内容池、可用音频与部署路径仍需落实。

## 先读四份文档

1. [整合方案与比赛定位](product/docs/08-integrated-plan.md)
2. [数据来源研究与下载建议](product/docs/09-data-research.md)
3. [技术选型与实施计划](product/docs/10-technical-plan.md)
4. [官方赛事依据与约束](product/docs/11-competition-reference.md)

完整交付导航见 **[product/README.md](product/README.md)**，规则以 [PRD v0.3](product/docs/01-PRD.md) 为准。

## 视觉方向

![Music Map × Music Space 设计概念，尚未实现](product/assets/concept-v0.3.png)

AI 生成的方向图，用于讨论“声场舞台 + 私人唱片馆”的构图与气质，不是产品运行截图。

## 体验已有原型

下载仓库后，用浏览器打开 [product/prototype/index.html](product/prototype/index.html)，保持 CSS、JS 文件完整。无需安装依赖，GitHub 文件预览页只显示源码。

可体验旋转、切中心、代表作抽屉、留下歌曲、历史回顾和合作挑战。它不包含真实音乐或新版视觉；历史检查见 [原型核验记录](product/verification/report.md)。

## 开发起点

建议正式应用放入 `web/`，采用 React + Vite + TypeScript、DOM / SVG 2.5D、单一持续播放器与 IndexedDB。先核实一条真实合作路线及手机可播资源，再实现“探索 → 封套 → Space → 再出发”。风格联系、照片与 PNG 导出排 P1。

官方初赛不提供 API 或额外模型额度；比赛歌单有赛事评审用途限制。Demo 的托管与访问方式须跟随实际素材条件，当前没有声称公开音乐服务已经完成。此轮只整理文档，没有提交或推送改动。
